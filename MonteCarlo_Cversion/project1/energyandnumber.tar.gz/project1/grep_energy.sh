#!/bin/sh

FOLDER=`pwd`
for filename in *.csv
do
    echo $filename
    #NAME=`sed -n 'basis H H.' $filename >> "${filename}kappa.csv"`
    `sed -n '/Energy/,/End of array./p' $filename >> "${filename}energy.csv"`
done
